document.addEventListener("DOMContentLoaded", () => {
    console.log("Lovable site loaded!");
});